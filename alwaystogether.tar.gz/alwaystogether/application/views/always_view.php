<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration</title>
    <link href="<?php echo base_url('assests/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assests/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>


  <div class="container">
    <h1>Information of all Candidates</h1>
</center>
    <h3>Data Store</h3>
    <br />
    <button class="btn btn-success" onclick="add_book()"><i class="glyphicon glyphicon-plus"></i> Add Book</button>
    <br />
    <br />
    <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
      <thead>
        <tr>
				    <th>First Name</th>
                    <th>Last Name</th>
                    <th>UID NO.</th>
                    <th>Father Name</th>
                    <th>Mother Name</th>
                    <th>Photo</th>
                    <th>Postal Address</th>
                    <th>City</th>
                    <th>District</th>
                    <th>State</th>
                    <th>Pincode</th>
                    <th>Phone No.</th>
                    <th>Mobile No.</th>
                    <th>Date Of Birth</th>
                    <th>AGE</th>
                    <th>Anniversary Date</th>
                    <th>Pan No.</th>
                    <th>Office Addresse</th>
                    <th>City</th>
                    <th>District</th>
                    <th>State</th>
                    <th>Occupation</th>
                    <th>Nominee Name</th>
                    <th>Nominee Age</th>
                    <th>Relation</th>

          <th style="width:125px;">Action</p></th>
        </tr>
      </thead>
      <tbody>
				<?php foreach($always as $item){?>
				     <tr>
				 <td><?php echo $item->id;?></td>
				 <td><?php echo $item->first_name;?></td>
				 <td><?php echo $item->last_name;?></td>
				 <td><?php echo $item->uid;?></td>
				 <td><?php echo $item->father_name;?></td>
                 <td><?php echo $item->mother_name;?></td>
                 <td><?php echo $item->postal_address;?></td>
                 <td><?php echo $item->postal_city;?></td>
                 <td><?php echo $item->postal_district;?></td>
                 <td><?php echo $item->postal_state;?></td>
                 <td><?php echo $item->pincode;?></td>
                 <td><?php echo $item->phone_no;?></td>
                 <td><?php echo $item->mobile_no;?></td>
                 <td><?php echo $item->dob;?></td>
                 <td><?php echo $item->age;?></td>
                 <td><?php echo $item->anniversary_date;?></td>
                 <td><?php echo $item->pan_no;?></td>
                 <td><?php echo $item->office_address;?></td>
                 <td><?php echo $item->office_city;?></td>
                 <td><?php echo $item->office_district;?></td>
                 <td><?php echo $item->office_state;?></td>
                 <td><?php echo $item->job;?></td>
                 <td><?php echo $item->nominee_name;?></td>
                 <td><?php echo $item->nominee_age;?></td>
                 <td><?php echo $item->relation;?></td>
								<td>
									<button class="btn btn-warning" onclick="edit_book(<?php echo $item->id;?>)"><i class="glyphicon glyphicon-pencil"></i></button>
									<button class="btn btn-danger" onclick="delete_book(<?php echo $item->id;?>)"><i class="glyphicon glyphicon-remove"></i></button>
                                </td>
				      </tr>
				     <?php }?>



      </tbody>
      <tfoot>
        <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>UID NO.</th>
                    <th>Father Name</th>
                    <th>Mother Name</th>
                    <th>Photo</th>
                    <th>Postal Address</th>
                    <th>City</th>
                    <th>District</th>
                    <th>State</th>
                    <th>Pincode</th>
                    <th>Phone No.</th>
                    <th>Mobile No.</th>
                    <th>Date Of Birth</th>
                    <th>AGE</th>
                    <th>Anniversary Date</th>
                    <th>Pan No.</th>
                    <th>Office Addresse</th>
                    <th>City</th>
                    <th>District</th>
                    <th>State</th>
                    <th>Occupation</th>
                    <th>Nominee Name</th>
                    <th>Nominee Age</th>
                    <th>Relation</th>   
        </tr>
      </tfoot>
    </table>

  </div>

  <script src="<?php echo base_url('assests/jquery/jquery-3.1.0.min.js')?>"></script>
  <script src="<?php echo base_url('assests/bootstrap/js/bootstrap.min.js')?>"></script>
  <script src="<?php echo base_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script>
  <script src="<?php echo base_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>


  <script type="text/javascript">
  $(document).ready( function () {
      $('#table_id').DataTable();
  } );
    var save_method; //for save method string
    var table;


    function add_book()
    {
      save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
    //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
    }

    function edit_book(id)
    {
      save_method = 'update';
      $('#form')[0].reset(); // reset form on modals

      //Ajax Load data from ajax
      $.ajax({
        url : "<?php echo site_url('index.php/always/ajax_edit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="id"]').val(data.id);
            $('[name="first_name"]').val(data.first_name);
            $('[name="last_name"]').val(data.last_name);
            $('[name="uid"]').val(data.uid);
            $('[name="father_name"]').val(data.father_name);
            $('[name="mother_name"]').val(data.mother_name);
            $('[name="postal_address"]').val(data.postal_address);
            $('[name="postal_city"]').val(data.postal_city);
            $('[name="postal_district"]').val(data.postal_district);
            $('[name="postal_state"]').val(data.postal_state);
            $('[name="pincode"]').val(data.pincode);
            $('[name="phone_no"]').val(data.phone_no);
            $('[name="mobile_no"]').val(data.mobile_no);
            $('[name="dob"]').val(data.dob);
            $('[name="age"]').val(data.age);
            $('[name="anniversary_date"]').val(data.anniversary_date);
            $('[name="office_address"]').val(data.office_address);
            $('[name="office_city"]').val(data.office_city);
            $('[name="office_district"]').val(data.office_district);
            $('[name="office_state"]').val(data.office_state);
            $('[name="job"]').val(data.job);
            $('[name="nominee_name"]').val(data.nominee_name);
            $('[name="nominee_age"]').val(data.nominee_age);
            $('[name="relation"]').val(data.relation);


            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit Details'); // Set title to Bootstrap modal title

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    }



    function save()
    {
      var url;
      if(save_method == 'add')
      {
          url = "<?php echo site_url('index.php/always/book_add')?>";
      }
      else
      {
        url = "<?php echo site_url('index.php/always/book_update')?>";
      }

       // ajax adding data to database
          $.ajax({
            url : url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
               $('#modal_form').modal('hide');
              location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
    }

    function delete_book(id)
    {
      if(confirm('Are you sure delete this data?'))
      {
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('index.php/always/book_delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });

      }
    }

  </script>

  <!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title">Registration Form</h3>
      </div>
      <div class="modal-body form">
        <form action="#" id="form" class="form-horizontal">
         <legend><h4>Fill Your Details Here:</h4></legend>
         <div class="row">
     <div class="col-sm-4">
         <div class="form-group">
             <label for="First_Name">First Name</label>
             <input type="text" class="form-control" name="first_name" placeholder="First Name">
         </div>
     </div>
      <div class="col-sm-4">
         <div class="form-group">
             <label for="Middle_Name">Last Name</label>
             <input type="text" class="form-control" name="last_name" placeholder="Last Name">
         </div>
     </div>
      <div class="col-sm-4">
         <div class="form-group">
             <label for="UID">UID NO.</label>
             <input type="value" class="form-control" name="uid" placeholder="UID NO">
         </div>
     </div>
         </div>
         <div class="row">
     <div class="col-sm-4">
         <div class="form-group">
             <label for="Father_Name">Father Name</label>
             <input type="text" class="form-control" name="father_name" placeholder="Father Name">
         </div>
     </div>
      <div class="col-sm-4">
         <div class="form-group">
             <label for="Mother_Name">Mother Name</label>
             <input type="text" class="form-control" name="mother_name" placeholder="Mother Name">
         </div>
     </div>
      <div class="col-sm-4">
         <div class="form-group">
            <label for="image">Image file</label>
            <input name="image_url" class="form-control" type="file" >
         </div>
     </div>
         </div>
     <div class="row">
         <div class="col-sm-8">
          <div class="form-group">
               <label for="address">Postal Address</label>
     <textarea name="postal_address" class="form-control" rows="4" required="required"></textarea>
          </div>
     </div>
          </div>
<div class="row">
     <div class="col-sm-4">
         <div class="form-group">
             <label for="City">City</label>
             <input type="text" class="form-control" name="postal_city" placeholder="City">
         </div>
     </div>
      <div class="col-sm-4">
         <div class="form-group">
             <label for="District">District</label>
             <input type="text" class="form-control" name="postal_district" placeholder="District">
         </div>
     </div>
      <div class="col-sm-4">
         <div class="form-group">
             <label for="State">State</label>
             <input type="text" class="form-control" name="postal_state" placeholder="State">
         </div>
     </div>
         </div>
         <div class="row">
     <div class="col-sm-4">
         <div class="form-group">
             <label for="PIN">Pincode</label>
             <input type="text" class="form-control" name="pincode" placeholder="Pincode">
         </div>
     </div>
      <div class="col-sm-4">
         <div class="form-group">
             <label for="phone">Phone No</label>
             <input type="text" class="form-control" name="phone_no" placeholder="Phone No">
         </div>
     </div>
      <div class="col-sm-4">
         <div class="form-group">
             <label for="mob">Mobile No</label>
             <input type="value" class="form-control" name="mobile_no" placeholder="Mob No">
         </div>
     </div>
     <div class="row">
     <div class="col-sm-3">
         <div class="form-group">
                  <label for="dob">DOB</label>
                 <input type="date" name="dob" class="form-control" required="required" title="DOB">
             </div>

     </div>
     <div class="col-sm-3">
         <div class="form-group">
             <label for="age">AGE</label>
             <input type="text" class="form-control" name="age" placeholder="AGE">
         </div>
     </div>
      <div class="col-sm-3">
         <div class="form-group">
                  <label for="anniversary_date">Anniversary_Date</label>
                 <input type="date" name="anniversary_date" class="form-control" title="Anniversary_Date">
             </div>

     </div>
      <div class="col-sm-3">
         <div class="form-group">
             <label for="pan">PAN No</label>
             <input type="value" class="form-control" name="pan_no" placeholder="PAN No">
         </div>
     </div>
     
 <div class="row">
         <div class="col-sm-6">
          <div class="form-group">
               <label for="address">Office Address</label>
     <textarea name="office_address" class="form-control" rows="4" required="required"></textarea>
          </div>
     </div>
          </div>
<div class="row">
     <div class="col-sm-4">
         <div class="form-group">
             <label for="City">City</label>
             <input type="text" class="form-control" name="office_city" placeholder="City">
         </div>
     </div>
      <div class="col-sm-4">
         <div class="form-group">
             <label for="District">District</label>
             <input type="text" class="form-control" name="office_district" placeholder="District">
         </div>
     </div>
      <div class="col-sm-4">
         <div class="form-group">
             <label for="State">State</label>
             <input type="value" class="form-control" name="office_state" placeholder="State">
         </div>
     </div>
         </div>
         <div class="row">
             <div class="col-sm-6">
                 <div class="form-group">
                     <label for="job">Occupation</label>
             <input type="text" class="form-control" name="job" placeholder="Occupation">
                 </div>
             </div>
             <div class="col-sm-6">
                 <div class="form-group">
                     <label for="nominee_name">Nominee Name</label>
             <input type="text" class="form-control" name="nominee_name" placeholder="Nominee Name">
                 </div>
             </div>
         </div>
         <div class="row">
             <div class="col-sm-3">
                 <div class="form-group">
                   <label for="nominee_age">Nominee AGE</label>
             <input type="text" class="form-control" name="nominee_age" placeholder="Enter Nominee_AGE:">  
                 </div>
             </div>
             <div class="col-sm-9">
                 <div class="form-group">
                     <label for="relation">Relation</label>
             <input type="text" class="form-control" name="relation" placeholder="Relation">
                 </div>
             </div>
         </div>
         <h3>Terms & Conditions:</h3>
        <div class="ul">
              <li>All rights are reserved for BMS Associates.</li>
              <li>Company can do any change in rules and regulations, without any 8information to customer.</li>
              <li>Home delivery and other services are depend on owner's company delivery service. BMS associate is not liable for this.</li>
              <li>Company is changing 1000/- for card only not for service charged.</li>
              <li>Customer is himself responsible for any problem is he/she purchase use service from comnpany.</li>
              <li>If customer have any problem with company then it can be solved only in Ludhiana Courts</li>
        </div>
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->

  </body>
</html>
