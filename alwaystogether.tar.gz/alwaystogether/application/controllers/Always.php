<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Always extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('always_model');
	 	}


	public function index()
	{

		$data['always']=$this->always_model->get_all_books();
		$this->load->view('always_view',$data);
	}
	public function book_add()
		{
			$data = array(
					'first_name' => $this->input->post('first_name'),
					'last_name' => $this->input->post('last_name'),
					'uid' => $this->input->post('uid'),
					'father_name' => $this->input->post('father_name'),
					'mother_name' => $this->input->post('mother_name'),
					'postal_address' => $this->input->post('postal_address'),
					'postal_city' => $this->input->post('postal_city'),
					'postal_district' => $this->input->post('postal_district'),
					'postal_state' => $this->input->post('postal_state'),
					'pincode' => $this->input->post('pincode'),
					'phone_no' => $this->input->post('phone_no'),
					'mobile_no' => $this->input->post('mobile_name'),
					'dob' => $this->input->post('dob'),
					'age' => $this->input->post('age'),
					'anniversary_date' => $this->input->post('anniversary_date'),
					'pan_no' => $this->input->post('pan_no'),
					'office_address' => $this->input->post('office_address'),
					'office_city' => $this->input->post('office_city'),
					'office_district' => $this->input->post('office_district'),
					'office_state' => $this->input->post('office_state'),
					'job' => $this->input->post('job'),
					'nominee_name' => $this->input->post('nominee_name'),
					'nominee_age' => $this->input->post('nominee_age'),
					'relation' => $this->input->post('relation'),
					
				);
			$insert = $this->always_model->book_add($data);
			echo json_encode(array("status" => TRUE));
		}
		public function ajax_edit($id)
		{
			$data = $this->always_model->get_by_id($id);



			echo json_encode($data);
		}

		public function book_update()
	{
		$data = array(
				    'first_name' => $this->input->post('first_name'),
					'last_name' => $this->input->post('last_name'),
					'uid' => $this->input->post('uid'),
					'father_name' => $this->input->post('father_name'),
					'mother_name' => $this->input->post('mother_name'),
					'postal_address' => $this->input->post('postal_address'),
					'postal_city' => $this->input->post('postal_city'),
					'postal_district' => $this->input->post('postal_district'),
					'postal_state' => $this->input->post('postal_state'),
					'pincode' => $this->input->post('pincode'),
					'phone_no' => $this->input->post('phone_no'),
					'mobile_no' => $this->input->post('mobile_name'),
					'dob' => $this->input->post('dob'),
					'age' => $this->input->post('age'),
					'anniversary_date' => $this->input->post('anniversary_date'),
					'pan_no' => $this->input->post('pan_no'),
					'office_address' => $this->input->post('office_address'),
					'office_city' => $this->input->post('office_city'),
					'office_district' => $this->input->post('office_district'),
					'office_state' => $this->input->post('office_state'),
					'job' => $this->input->post('job'),
					'nominee_name' => $this->input->post('nominee_name'),
					'nominee_age' => $this->input->post('nominee_age'),
					'relation' => $this->input->post('relation'),
			);
		$this->book_model->book_update(array('id' => $this->input->post('id')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function book_delete($id)
	{
		$this->always_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}



}
